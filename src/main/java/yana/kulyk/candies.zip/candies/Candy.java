package yana.kulyk.candies;



public class Candy extends Sweet{

   public Candy(String name, double weight){
        super(name, weight);
    }

}
