package yana.kulyk.candies;


import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Sweet sweet1 = new Candy("Rafaello", 2);
        Sweet sweet2 = new Candy("Ferero", 4);
        Sweet sweet3 = new Cookie("Oreo",1.5);

        Sweet[] sweets = {sweet1, sweet2, sweet3};
        System.out.println(sumWeight(sweets));

    }
    public static double sumWeight(Sweet[] sweets) {
        double weight = 0;
        for (Sweet sweet : sweets) {
            weight += sweet.getWeight();
        }
        return weight;
    }

}

