package yana.kulyk.candies;


public class Cookie extends Sweet {

    public Cookie(String name, double weight){
        super(name,weight);
    }
}
